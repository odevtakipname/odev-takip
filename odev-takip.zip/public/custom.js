function successModal(title,message) {
    Swal.fire(
        title,
        message,
        'success'
      )
}
function errorModal(title,message) {
    Swal.fire(
        title,
        message,
        'error'
      )
}