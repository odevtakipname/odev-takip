

</div>
</div>
  <!--dashboard-->
    <!-- Required vendors -->
    <script type="application/javascript" src="{{asset('frontend/vendor/global/global.min.js')}}"></script>
	  <script type="application/javascript" src="{{asset('frontend/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')}}"></script>
    <script type="application/javascript" src="{{asset('frontend/js/custom.min.js')}}"></script>
    <script type="application/javascript" src="{{asset('frontend/js/deznav-init.js')}}"></script>

    <script type="application/javascript" src="{{asset('frontend/vendor/owl-carousel/owl.carousel.js')}}"></script>
    
    <!-- Chart piety plugin files -->
      <script type="application/javascript" src="{{asset('frontend/vendor/peity/jquery.peity.min.js')}}"></script>
    
    <!-- Apex Chart -->
    <script type="application/javascript" src="{{asset('frontend/vendor/apexchart/apexchart.js')}}"></script>
   
    <script type="application/javascript" src="{{asset('frontend/js/dashboard/dashboard-1.js')}}"></script>
        <!-- Toastr -->
        <script src="{{asset('frontend/vendor/toastr/js/toastr.min.js')}}"></script>

        <!-- All init script -->
        <script src="{{asset('frontend/js/plugins-init/toastr-init.js')}}"></script>
    <script  src="{{mix('js/app.js')}}"></script>

</body>
</html>
