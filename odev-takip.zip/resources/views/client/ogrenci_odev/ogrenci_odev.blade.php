@extends('client.layouts.default')

@section('content')
    <ogrenci-odev></ogrenci-odev>
@endsection