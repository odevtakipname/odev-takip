@extends('client.layouts.default')

@section('content')
    <add-user></add-user>
@endsection