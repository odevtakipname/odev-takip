@extends('client.layouts.default')

@section('content')
    <ogrenci-list></ogrenci-list>
@endsection