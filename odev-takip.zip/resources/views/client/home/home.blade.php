@extends('client.layouts.default')

@section('content')
    <div class="right_col" role="main" style="min-height: 97vh">
        <!-- top tiles -->
        <div class="col-md-12">
            <main-comp></main-comp>
        </div>

    </div>
@endsection
