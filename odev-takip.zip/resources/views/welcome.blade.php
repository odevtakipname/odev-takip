@extends('client.layouts.default')

@section('content')
<div class="right_col" role="main">
    <!-- top tiles -->
    <div class="col-md-12">
    
  

    </div>

</div>
@endsection