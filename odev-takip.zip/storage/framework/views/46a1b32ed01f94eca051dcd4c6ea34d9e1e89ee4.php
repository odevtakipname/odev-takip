

<?php $__env->startSection('content'); ?>
    <add-user></add-user>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projects\odev-takip\resources\views/client/kullanicilar/kullanicilar.blade.php ENDPATH**/ ?>