

<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main" style="min-height: 97vh">
        <!-- top tiles -->
        <div class="col-md-12">
            <main-comp></main-comp>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projects\traking2\resources\views/client/home/home.blade.php ENDPATH**/ ?>