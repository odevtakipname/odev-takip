

<?php $__env->startSection('content'); ?>
    <donem></donem>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projects\traking2\resources\views/client/donem/donem.blade.php ENDPATH**/ ?>